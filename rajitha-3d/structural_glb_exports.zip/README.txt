Structural GLB exports

These are approximate 3D reconstructions created from the uploaded screenshots. They are intended for portfolio visualization only. They are NOT original Tekla/Revit/analysis models and must not be used for engineering, fabrication, quantities, or design verification. Screenshot-only input cannot recover exact hidden geometry, member profiles, dimensions, connections, or analysis data.

Files:
01_industrial_pitched_roof_frame.glb
02_industrial_design_status_pass_fail.glb
03_multistorey_structural_frame.glb
04_tall_tower_dense_floor_frame.glb
05_structural_analysis_results_visual.glb

RAJITHA KURUMALLA — PORTFOLIO ASSET PACK

Copy the contents of projects/ into public/assets/portfolio/projects/ and certificates/ into public/assets/portfolio/certificates/ in the Vite project.

Project groups:
- residential-building-design: residential floor plans and 3D/elevation visuals
- rcc-structural-modelling: RCC frame, foundation, reinforcement schedule and drawing visuals
- autocad-technical-drawings: AutoCAD sample PDFs and reference images
- revit-modelling: Revit sample PDF

Certificate PDFs are copied as provided. Please confirm the exact certificate titles, issuers and dates before publishing metadata on the website.
